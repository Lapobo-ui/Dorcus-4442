%Importation from spreadsheet and writing table
warclass=readtable("C:\Users\DIL\Desktop\ALL ASSIGNMENTS group4\WAR CLASS.xlsx");
disp(warclass);
writetable(warclass,"GROUP 4.xlsx");

%compute GPA for students
n=input('enter number of courses:');
totalpoints=0;
totalcredits=0;
for i=1:n
    disp(['Course',num2str(i)]);
    credit=input('enter credit units:');
    gradepoint=input('enter grade point:');
    totalpoints=totalpoints+credit*gradepoint;
    totalcredits=totalcredits+credit;
end
GPA=totalpoints/totalcredits;
disp(['GPA=',num2str(GPA)]);

%compute CGPA for students
semesters=input("enter number of semesters:");
totalweightGPA=0;
totalcredits=0;
for s=1:semesters
    disp(['semester',num2str(s)]);
    GPA=input("enter GPA for this semester:");
    credits=input("enter total credit units:");
    totalweightGPA=totalweightGPA+GPA*credits;
    totalcredits=totalcredits+credits;
end
CGPA=totalweightGPA/totalcredits;
disp(['CGPA=',num2str(CGPA)]);

%use plot function
WARCLASS=readtable("C:\Users\DIL\Desktop\ALL ASSIGNMENTS group4\WAR CLASS.xlsx");
x=WARCLASS.CGPA;
y=WARCLASS.MARKS;
plot(x,y);
xlabel('CGPA');
ylabel('MARKS');
title('CGPA AGAINST MARKS');
grid on;

%use bar function
WARCLASS=readtable("C:\Users\DIL\Desktop\ALL ASSIGNMENTS group4\WAR CLASS.xlsx");
x=WARCLASS.Name;
y=WARCLASS.MARKS;
bar(x,y);
xlabel('CGPA');
ylabel('MARKS');
title('NAME AGAINST MARKS');
grid on;

%IMAGE PROCESSING ASSIGNMENT
LeavesData=struct('No',{1,2,3,4,5},'CommonName',{'mango','cassava','maize','bean','hibiscus'},'LeafType',{'simple','compound(palmate)','simple','compound(trifoliate)','simple'},'Venation',{'Reticulate','Reticulate','Parallel','Reticulate','Reticulate'},'Margin',{'entire','entire(lobbed)','entire','entire','serrated'},'OriginalImagePath',{'mango leaf.jpeg','cassava leaf.jpeg','maize leaf.jpeg','bean leaf.jpeg','hibiscus leaf.jpeg'},'ProcessedImagePath',{'mango-processed.jpeg','cassava-processed.jpeg','maize-processed.jpeg','bean-processed.jpeg','hibiscuss-processed.jpeg'});
fprintf('Structural array successfully created for %d leaf types.\n',length(LeavesData));
for i=1:length(LeavesData)
    currentImageName=LeavesData(i).OriginalImagePath;
    imgOriginal=imread(currentImageName);
    imgGray=rgb2gray(imgOriginal);
    thresholdValue=graythresh(imgGray);
    imgBinary=imbinarize(imgGray,thresholdValue);
    imgEdges=edge(imgGray,'canny');
    imwrite(imgEdges,LeavesData(i).ProcessedImagePath);
end

%FLOW CHART ASSIGNMENT
%Newton-Raphson method
%for-loop version 
f  = @(x) x^3 - 2*x - 5;      % function
df = @(x) 3*x^2 - 2;          % derivative of f(x)
 
x0  = 2;        % initial guess
tol = 1e-6;     % tolerance
N   = 50;       % maximum number of iterations
 
fprintf('Newton-Raphson Method (for loop)\n');
fprintf('iter\t   x0\t\t   x1\t\t   |x1-x0|\n');
 
for iter = 1:N
    x1 = x0 - f(x0)/df(x0);
    err = abs(x1 - x0);
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', iter, x0, x1, err);
 
    if err < tol
        break
    end
    x0 = x1;
end
 
fprintf('\nApproximate root = %.6f\n', x1);
fprintf('Number of iterations = %d\n', iter);
fprintf('Check: f(root) = %.2e\n', f(x1));

%while-loop version
clear; clc;
 
f  = @(x) x^3 - 2*x - 5;      % function
df = @(x) 3*x^2 - 2;          % derivative of f(x)
 
x0  = 2;        % initial guess
tol = 1e-6;     % tolerance
N   = 50;       % maximum number of iterations
 
fprintf('Newton-Raphson Method (while loop)\n');
fprintf('iter\t   x0\t\t   x1\t\t   |x1-x0|\n');
 
iter = 0;
err  = Inf; 
while err >= tol && iter < N
    x1  = x0 - f(x0)/df(x0);
    err = abs(x1 - x0);
    iter = iter + 1;
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', iter, x0, x1, err);
 
    x0 = x1;
end
 
fprintf('\nApproximate root = %.6f\n', x1);
fprintf('Number of iterations = %d\n', iter);


%SECANT METHOD
%for-Loop version
 
f = @(x) x^3 - 2*x - 5; % function (no derivative needed)
 
x0 = 1;     % first initial guess
x1  = 3;        % second initial guess
tol = 1e-6;     % tolerance
N   = 50;       % maximum number of iterations
 
fprintf('Secant Method (for loop)\n');
fprintf('iter\t   x1\t\t   x2\t\t   |x2-x1|\n');
 
for iter = 1:N
    x2  = x1 - f(x1)*(x1 - x0)/(f(x1) - f(x0));
    err = abs(x2 - x1);
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', iter, x1, x2, err);
 
    if err < tol
        break
    end
    x0 = x1;
    x1 = x2;
end
 
fprintf('\nApproximate root = %.6f\n', x2);
fprintf('Number of iterations = %d\n', iter);
fprintf('Check: f(root) = %.2e\n', f(x2));

%While-Loop version
f = @(x) x^3 - 2*x - 5;   % function (no derivative needed)
 
x0  = 1;        % first initial guess
x1  = 3;        % second initial guess
tol = 1e-6;     % tolerance
N   = 50;       % maximum number of iterations
 
fprintf('Secant Method (while loop)\n');
fprintf('iter\t   x1\t\t   x2\t\t   |x2-x1|\n');
 
iter = 0;
err  = Inf;
 
while err >= tol && iter < N
    x2  = x1 - f(x1)*(x1 - x0)/(f(x1) - f(x0));
    err = abs(x2 - x1);
    iter = iter + 1;
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', iter, x1, x2, err);
 
    x0 = x1;
    x1 = x2;
end
 
fprintf('\nApproximate root = %.6f\n', x2);
fprintf('Number of iterations = %d\n', iter);
fprintf('Check: f(root) = %.2e\n', f(x2));

%FOURHT ORDER RUNGE-KUTTA METHOD
%for-loop version
f = @(x, y) x + y;   % dy/dx = f(x,y)
x0 = 0;         % initial x
y0 = 1;         % initial y
h  = 0.1;       % step size
xn = 0.4;       % final x value
 
n = round((xn - x0)/h);   % number of steps
 
x = x0;
y = y0;
 
fprintf('4th Order Runge-Kutta Method (for loop)\n');
fprintf('step\t   x\t\t   y\n');
fprintf('%d\t%.4f\t%.6f\n', 0, x, y);
 
for i = 1:n
    k1 = f(x, y);
    k2 = f(x + h/2, y + h*k1/2);
    k3 = f(x + h/2, y + h*k2/2);
    k4 = f(x + h,   y + h*k3);
 
    y = y + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
    x = x + h;
 
    fprintf('%d\t%.4f\t%.6f\n', i, x, y);
end
 
fprintf('\nApproximate y(%.1f) = %.6f\n', xn, y);

%while-loop version
f = @(x, y) x + y;   % dy/dx = f(x,y)
 
x0 = 0;         % initial x
y0 = 1;         % initial y
h  = 0.1;       % step size
xn = 0.4;       % final x value
 
x = x0;
y = y0;
step = 0;
 
fprintf('4th Order Runge-Kutta Method (while loop)\n');
fprintf('step\t   x\t\t   y\n');
fprintf('%d\t%.4f\t%.6f\n', step, x, y);
 
while x < xn - 1e-10     % small tolerance guards against float round-off
    k1 = f(x, y);
    k2 = f(x + h/2, y + h*k1/2);
    k3 = f(x + h/2, y + h*k2/2);
    k4 = f(x + h,   y + h*k3);
 
    y = y + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
    x = x + h;
    step = step + 1;
 
    fprintf('%d\t%.4f\t%.6f\n', step, x, y);
end
 
fprintf('\nApproximate y(%.1f) = %.6f\n', xn, y);

